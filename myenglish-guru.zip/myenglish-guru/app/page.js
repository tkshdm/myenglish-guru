export default function Home() {
  return (
    <div className="chat-container">
      <h2>Select Your Teacher</h2>

      <a href="/chat?teacher=maya">🇮🇳 Maya (Beginner)</a><br/><br/>
      <a href="/chat?teacher=sara">🌍 Sara (Intermediate)</a><br/><br/>
      <a href="/chat?teacher=aisha">🌍 Aisha (Advanced)</a>
    </div>
  );
}
