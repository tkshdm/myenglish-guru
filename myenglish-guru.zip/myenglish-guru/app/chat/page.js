"use client";
import { useState } from "react";

export default function ChatPage() {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");

  const teacher = typeof window !== "undefined"
    ? new URLSearchParams(window.location.search).get("teacher")
    : "maya";

  async function sendMessage() {
    if (!input) return;
    const msg = input;
    setInput("");

    setMessages(prev => [...prev, { role: "user", content: msg }]);

    const res = await fetch("/api/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message: msg, teacher }),
    });

    const data = await res.json();

    setMessages(prev => [...prev, { role: "bot", content: data.reply }]);
  }

  return (
    <div className="chat-container">
      <h3>Chat with {teacher}</h3>

      {messages.map((m, i) => (
        <div key={i} className={`message ${m.role}`}>
          {m.content}
        </div>
      ))}

      <input
        style={{ width: "100%", padding: "10px" }}
        value={input}
        onChange={(e) => setInput(e.target.value)}
        placeholder="Type message..."
      />

      <button style={{ width: "100%", marginTop: "10px" }} onClick={sendMessage}>
        Send
      </button>
    </div>
  );
}
