import { NextResponse } from "next/server";

export async function POST(req) {
  const body = await req.json();
  const { message, teacher } = body;

  const teacherPrompts = {
    maya: "You are Maya, an Indian beginner-level English tutor. Use very simple English + Hindi explanation.",
    sara: "You are Sara, intermediate English tutor. Mix Hindi and English. Explain grammar simply.",
    aisha: "You are Aisha, advanced tutor. Use full English. Focus on fluency and corrections.",
  };

  const finalPrompt = teacherPrompts[teacher] || teacherPrompts.maya;

  const openaiRes = await fetch("https://api.openai.com/v1/chat/completions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: "Bearer " + process.env.OPENAI_API_KEY,
    },
    body: JSON.stringify({
      model: "gpt-4o-mini",
      messages: [
        { role: "system", content: finalPrompt },
        { role: "user", content: message },
      ],
    }),
  });

  const json = await openaiRes.json();

  return NextResponse.json({
    reply: json.choices?.[0]?.message?.content || "Error",
  });
}
